package com.example.myapp


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.commit
import com.example.myapp.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    val binding by lazy {ActivityMainBinding.inflate(layoutInflater)}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val fManager = supportFragmentManager
        fManager.commit {
            add(binding.frameLayout.id,MapFragment()) }
        //message버튼을 누르면 채팅 프래그먼트로 이동
        binding.messageButton.setOnClickListener{
            //현재 프래그먼트가 채팅방이 아니라면 이동시키게함
            val currentFragment = fManager.findFragmentById(binding.frameLayout.id)
            if (currentFragment !is ChatFragment) {
                fManager.commit {
                    replace(binding.frameLayout.id,ChatFragment())
                }
            }
        }
        //map 버튼을 누르면 채팅 프래그먼트로 이동
        binding.mapButton.setOnClickListener{
            //현재 프래그먼트가 맵이 아니라면 이동시키게 함
            val currentFragment = fManager.findFragmentById(binding.frameLayout.id)
            if (currentFragment !is MapFragment){
                fManager.commit {
                    replace(binding.frameLayout.id,MapFragment())
                }
            }
        }
    }
}