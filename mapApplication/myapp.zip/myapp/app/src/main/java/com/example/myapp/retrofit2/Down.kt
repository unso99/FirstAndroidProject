package com.example.retrofit_example.retrofit2

data class Down(
    val time: List<Time>
)