package com.example.retrofit_example.retrofit2

data class OrdList(
    val down: Down,
    val up: Up
)