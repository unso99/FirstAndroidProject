package com.example.retrofit_example.retrofit2

data class Up(
    val time: List<Time>
)