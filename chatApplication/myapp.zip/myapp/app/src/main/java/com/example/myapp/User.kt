package com.example.myapp

data class User(
    val uid:String?=""
)