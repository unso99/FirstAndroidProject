package com.example.myapp


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.fragment.app.commit
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase


class MainActivity : AppCompatActivity() {
    lateinit var auth: FirebaseAuth
    lateinit var myUid: String

    val binding by lazy {ActivityMainBinding.inflate(layoutInflater)}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        //FirebaseAuth 객체의 인스턴스 가져오기
        auth = FirebaseAuth.getInstance()
        //익명으로 로그인
        Anonymoulsy()
        //지하철역 채팅방 생성
        //stationset()

        val fManager = supportFragmentManager
        fManager.commit {
            add(binding.frameLayout.id,MapFragment()) }

        //message버튼을 누르면 채팅 프래그먼트로 이동
        binding.messageButton.setOnClickListener{
            //현재 프래그먼트가 채팅방이 아니라면 이동시키게함
            val currentFragment = fManager.findFragmentById(binding.frameLayout.id)
            if (currentFragment !is ChatFragment) {
                fManager.commit {
                    replace(binding.frameLayout.id,ChatFragment())
                }
            }
        }
        //map 버튼을 누르면 채팅 프래그먼트로 이동
        binding.mapButton.setOnClickListener{
            //현재 프래그먼트가 맵이 아니라면 이동시키게 함
            val currentFragment = fManager.findFragmentById(binding.frameLayout.id)
            if (currentFragment !is MapFragment){
                fManager.commit {
                    replace(binding.frameLayout.id,MapFragment())
                }
            }
        }
    }
    // Firebase Authentication 익명으로 로그인
    fun Anonymoulsy() {
        auth.signInAnonymously()
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d("Login", "signInAnonymously:success")
                    val user = auth.currentUser
                    updateUI(user)
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w("Login", "signInAnonymously:failure", task.exception)
                    Toast.makeText(
                        baseContext,
                        "Authentication failed.",
                        Toast.LENGTH_SHORT,
                    ).show()
                    updateUI(null)
                }
            }

    }
    private fun updateUI(user: FirebaseUser?) { //update ui code here
        if (user != null) {
            myUid = FirebaseAuth.getInstance().currentUser?.uid.toString()
            Log.d("Login", myUid)
            FirebaseDatabase.getInstance().getReference("User").child("users")
                .child(myUid).setValue(User(myUid))
        }
}
    /*//지하철 역마다 채팅방 생성
    fun stationset() {
        val allStations: ArrayList<Station> = arrayListOf<Station>(         //전체 역 목록
            Station("공릉역"),
            Station("하계역"),
            Station("태릉입구역"),
            Station("석계역"),
            Station("먹골역"),
            Station("화랑대역"),
            Station("gongreung"),
            Station("ginn")
        )

        for (i in 0..7) {
            FirebaseDatabase.getInstance().getReference("Station").child("stations")
                .child(allStations[i].name)
                .push().setValue(allStations[i]).addOnSuccessListener {
                    Log.i("putMessage", "채팅방 생성에 성공하였습니다.")
                }
        }
    }*/
}