package com.example.myapp

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myapp.databinding.ItemChatMineBinding
import com.example.myapp.databinding.ItemChatOthersBinding
import com.example.myapp.databinding.ItemImageMineBinding
import com.example.myapp.databinding.ItemImageOthersBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.getValue


class MessageAdapter(val messages: ArrayList<ChatData>): RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val myUid = FirebaseAuth.getInstance().currentUser?.uid.toString()


    //메시지의 id에 따라 내 메시지/상대 메시지 구분
    override fun getItemViewType(position: Int): Int {
        val message = messages[position]
        return when {
            message.send_uid == myUid && message.imageUrl == null -> 0
            message.send_uid == myUid && message.imageUrl != null -> 1
            message.send_uid != myUid && message.imageUrl == null -> 2
            message.send_uid != myUid && message.imageUrl != null -> 3
            else -> throw IllegalArgumentException("Invalid message type")
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            //메시지가 내 메시지이고 문자인 경우
            0 -> {
                val binding = ItemChatMineBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return MyMessageViewHolder(binding)
            }
            //메시지가 내 메시지이고 이미지인 경우
            1 -> {
                val binding = ItemImageMineBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return MyImageViewHolder(binding)
            }
            //메시지가 상대 메시지이고 문자인 경우
            2 -> {
                val binding = ItemChatOthersBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return OthersMessageViewHolder(binding)
            }
            //메시지가 상대 메시지이고 이미지인 경우
            3 -> {
                val binding = ItemImageOthersBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return OthersImageViewHolder(binding)
            }
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (getItemViewType(position)) {
            0 -> {
                (holder as MyMessageViewHolder).bind(messages[position])
        }
            1 -> {
                (holder as MyImageViewHolder).bind(messages[position])
            }
            2 -> {
                (holder as OthersMessageViewHolder).bind(messages[position])
            }
            3 -> {
                (holder as OthersImageViewHolder).bind(messages[position])
            }
        }
    }

    override fun getItemCount(): Int {
        return messages.size
    }
    fun getDateText(sendDate: String): String {
        var dateText = ""
        var timeString = ""
        if (sendDate.isNotBlank()) {
            timeString = sendDate.substring(8, 12)
            var hour = timeString.substring(0, 2)
            var minute = timeString.substring(2, 4)

            var timeformat = "%02d:%02d"

            if (hour.toInt() > 11) {
                dateText += "오후 "
                dateText += timeformat.format(hour.toInt() - 12, minute.toInt())
            } else {
                dateText += "오전 "
                dateText += timeformat.format(hour.toInt(), minute.toInt())
            }
        }
        return dateText
    }

    inner class MyMessageViewHolder(val binding: ItemChatMineBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(chat: ChatData) {
            //메시지 UI 항목 초기화
            binding.txtMessage.text = chat.msg
            binding.txtDate.text = getDateText(chat.send_time)
        }
    }
    inner class MyImageViewHolder(val binding: ItemImageMineBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(image: ChatData) {
            //메시지 UI 항목 초기화
            Glide.with(binding.imageView).load(image.imageUrl).override(500, 500).into(binding.imageView)
            binding.txtDate.text = getDateText(image.send_time)
        }
    }
    inner class OthersMessageViewHolder(private val binding: ItemChatOthersBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(chat: ChatData) {
            //메시지 UI 항목 초기화
            binding.txtMessage.text = chat.msg
            binding.txtDate.text = getDateText(chat.send_time)
        }
    }
    inner class OthersImageViewHolder(val binding: ItemImageOthersBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(image: ChatData) {
            //메시지 UI 항목 초기화
            Glide.with(binding.imageView2).load(image.imageUrl).override(500, 500).into(binding.imageView2)
            binding.txtDate.text = getDateText(image.send_time)
        }
    }
}