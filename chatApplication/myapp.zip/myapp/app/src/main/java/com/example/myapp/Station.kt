package com.example.myapp

data class Station(
    val name: String =""
)