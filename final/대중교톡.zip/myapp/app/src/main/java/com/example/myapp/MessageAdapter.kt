package com.example.myapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myapp.databinding.ItemChatMineBinding
import com.example.myapp.databinding.ItemChatOthersBinding
import com.example.myapp.databinding.ItemImageMineBinding
import com.example.myapp.databinding.ItemImageOthersBinding
import com.google.firebase.auth.FirebaseAuth

class MessageAdapter(val messages: ArrayList<ChatData>): RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val myUid = FirebaseAuth.getInstance().currentUser?.uid.toString()

    //메시지의 uid와 타입에 따라 내 메시지(일반, 이미지)/상대 메시지(일반, 이미지) 구분
    override fun getItemViewType(position: Int): Int {
        val message = messages[position]
        return when {
            message.send_uid == myUid && message.imageUrl == null -> 0  //받아온 message의 uid와 현재 사용자(=나)의 uid가 같고 imgaeUrl이 null => 내가 보낸 일반 메시지
            message.send_uid == myUid && message.imageUrl != null -> 1  //받아온 message의 uid와 현재 사용자(=나)의 uid가 같고 imgaeUrl이 null이 아닌 경우 => 내가 보낸 이미지 메시지
            message.send_uid != myUid && message.imageUrl == null -> 2  //받아온 message의 uid와 현재 사용자(=나)의 uid가 다르고 imgaeUrl이 null => 상대방이 보낸 일반 메시지
            message.send_uid != myUid && message.imageUrl != null -> 3  //받아온 message의 uid와 현재 사용자(=나)의 uid가 다르고 imgaeUrl이 null이 아닌 경우 => 상대방이 보낸 이미지 메시지
            else -> throw IllegalArgumentException("Invalid message type")  //모든 경우의 수에 해당하지 않을 때 예외 발생
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            //내가 보낸 메시지이고 텍스트인 경우
            0 -> {
                val binding = ItemChatMineBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return MyMessageViewHolder(binding)
            }
            //내가 보낸 메시지이고 이미지인 경우
            1 -> {
                val binding = ItemImageMineBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return MyImageViewHolder(binding)
            }
            //상대방이 보낸 메시지이고 텍스트인 경우
            2 -> {
                val binding = ItemChatOthersBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return OthersMessageViewHolder(binding)
            }
            //상대방이 보낸 메시지이고 이미지인 경우
            3 -> {
                val binding = ItemImageOthersBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return OthersImageViewHolder(binding)
            }
            else -> throw IllegalArgumentException("Invalid view type")     //모든 경우의 수에 해당하지 않을 때 예외 발생
        }
    }

    //RecyclerView의 각 아이템에 대한 뷰를 설정
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        //getItemViewType 함수를 통해 viewType 확인하여 해당 ViewHolder 사용
        when (getItemViewType(position)) {
            0 -> {
                (holder as MyMessageViewHolder).bind(messages[position])
            }
            1 -> {
                (holder as MyImageViewHolder).bind(messages[position])
            }
            2 -> {
                (holder as OthersMessageViewHolder).bind(messages[position])
            }
            3 -> {
                (holder as OthersImageViewHolder).bind(messages[position])
            }
        }
    }
    override fun getItemCount(): Int {
        return messages.size
    }
    // 전달된 날짜 문자열 시간으로 변환
    fun getDateText(sendDate: String): String {
        var dateText = ""
        var timeString = ""
        if (sendDate.isNotBlank()) {
            timeString = sendDate.substring(8, 12)
            var hour = timeString.substring(0, 2)
            var minute = timeString.substring(2, 4)

            var timeformat = "%02d:%02d"

            if (hour.toInt() > 11) {
                dateText += "오후 "
                dateText += timeformat.format(hour.toInt() - 12, minute.toInt())
            } else {
                dateText += "오전 "
                dateText += timeformat.format(hour.toInt(), minute.toInt())
            }
        }
        return dateText
    }
    // 해당 ViewHolder에 대한 바인딩 객체를 경우에 따라 모두 다르게 설정
    // 내가 보낸 메시지이며 텍스트 메시지 일 때
    inner class MyMessageViewHolder(val binding: ItemChatMineBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(chat: ChatData) {  //데이터 뷰 홀더에 바인딩
            binding.txtMessage.text = chat.msg  //채팅 메시지 표시
            binding.txtDate.text = getDateText(chat.send_time)  //채팅 메시지 시간 표시
        }
    }
    // 내가 보낸 메시지이며 이미지 메시지 일 때
    inner class MyImageViewHolder(val binding: ItemImageMineBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(image: ChatData) {
            //이미지 URL 로드 후 크기 조정하여 imageView에 표시
            Glide.with(binding.imageView).load(image.imageUrl).override(500, 500).into(binding.imageView)
            binding.txtDate.text = getDateText(image.send_time)//채팅 메시지 시간 표시
        }
    }
    // 상대방이 보낸 메시지이며 텍스트 메시지 일 때
    inner class OthersMessageViewHolder(val binding: ItemChatOthersBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(chat: ChatData) {
            binding.txtMessage.text = chat.msg
            binding.txtDate.text = getDateText(chat.send_time)
        }
    }
    // 상대방이 보낸 메시지이며 이미지 메시지 일 때
    inner class OthersImageViewHolder(val binding: ItemImageOthersBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(image: ChatData) {
            Glide.with(binding.imageView2).load(image.imageUrl).override(500, 500).into(binding.imageView2)
            binding.txtDate.text = getDateText(image.send_time)
        }
    }
}