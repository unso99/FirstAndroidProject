package com.example.myapp

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp.databinding.ActivityChatRoomBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.getValue
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

//채팅방에 대한 activity
class ChatRoomActivity : AppCompatActivity() {
    val binding by lazy { ActivityChatRoomBinding.inflate(layoutInflater) }
    lateinit var myUid: String
    val messages = arrayListOf<ChatData>()
    var messageKeys: ArrayList<String> = arrayListOf()   //메시지 키 목록

    var adapter = MessageAdapter(messages)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        // 채팅창이 공백일 경우 버튼 비활성화
        binding.editMessage.addTextChangedListener { text ->
            binding.btnSend.isEnabled = text.toString() != ""
        }
        // 메시지 전송 버튼 눌렀을 때
        binding.btnSend.setOnClickListener() {
            putMessage()
            getMessage()
        }
        binding.recyclerMessage.adapter = adapter
        binding.recyclerMessage.layoutManager = LinearLayoutManager(this@ChatRoomActivity)

    }

    /*fun setupChatRoomKey() {            //chatRoomKey 없을 경우 초기화 후 목록 초기화
        FirebaseDatabase.getInstance().getReference("ChatRoom")
            .child("chatRooms").orderByChild("users/${opponentUser.uid}").equalTo(true)    //상대방의 Uid가 포함된 목록이 있는지 확인
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onCancelled(error: DatabaseError) {}
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (data in snapshot.children) {
                        chatRoomKey = data.key!!          //chatRoomKey 초기화
                        setupRecycler()                  //목록 업데이트
                        break
                    }
                }
            })
    }*/
    //메세지 전송 함수
    fun putMessage() {
        val msg = binding.editMessage.getText().toString()
        myUid = FirebaseAuth.getInstance().currentUser?.uid.toString()
        val chat = ChatData(myUid, msg, getDateTimeString())
        //Log.d("putMessage", chat.msg)
        Log.d("putMessage", getDateTimeString())
        FirebaseDatabase.getInstance().getReference("ChatRoom").child("chatRooms").child("messages")
            .push().setValue(chat).addOnSuccessListener {
                Log.i("putMessage", "메시지 전송에 성공하였습니다.")
                binding.editMessage.text.clear()
            }.addOnCanceledListener {
                Log.i("putMessage", "메시지 전송에 실패하였습니다")
            }
    }

    fun getMessage() {
        FirebaseDatabase.getInstance().getReference("ChatRoom").child("chatRooms").child("messages")
            .addValueEventListener(object : ValueEventListener {
                override fun onCancelled(error: DatabaseError) {}
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    messages.clear()
                    for (data in dataSnapshot.children) {
                        messages.add(data.getValue<ChatData>()!!)
                        messageKeys.add(data.key!!)
                    }
                    adapter.notifyDataSetChanged()          //화면 업데이트
                    binding.recyclerMessage.scrollToPosition(messages.size - 1)    //스크롤 최 하단으로 내리기
                }
            })
    }
    //메시지 보낸 시각 정보 반환
    fun getDateTimeString(): String {
        var localDateTime = LocalDateTime.now()
        localDateTime.atZone(TimeZone.getDefault().toZoneId())
        var dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
        return localDateTime.format(dateTimeFormatter).toString()
    }

}


