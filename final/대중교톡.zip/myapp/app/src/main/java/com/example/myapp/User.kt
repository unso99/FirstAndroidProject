package com.example.myapp

// 익명으로 로그인 한 사용자 정보 저장하는 객체
data class User(
    val uid:String?=""  //사용자 uid
)