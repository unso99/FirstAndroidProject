package com.example.retrofit_example.retrofit2

data class SunList(
    val down: Down,
    val up: Up
)