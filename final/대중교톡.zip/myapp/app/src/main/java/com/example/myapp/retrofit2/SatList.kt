package com.example.retrofit_example.retrofit2

data class SatList(
    val down: Down,
    val up: Up
)