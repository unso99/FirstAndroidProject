package com.example.myapp

import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Context.ALARM_SERVICE
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat.getSystemService
import androidx.core.view.get
import androidx.fragment.app.commit
import com.example.myapp.databinding.FragmentMapBinding
import com.example.retrofit_example.retrofit2.Time
import com.example.retrofit_example.retrofit2.stationTimeTableDTO
import com.google.gson.JsonObject
import com.naver.maps.geometry.LatLng
import com.naver.maps.map.CameraPosition
import com.naver.maps.map.CameraUpdate
import com.naver.maps.map.LocationTrackingMode
import com.naver.maps.map.NaverMap
import com.naver.maps.map.NaverMapOptions
import com.naver.maps.map.OnMapReadyCallback
import com.naver.maps.map.overlay.InfoWindow
import com.naver.maps.map.overlay.Marker
import com.naver.maps.map.overlay.Overlay
import com.naver.maps.map.overlay.OverlayImage
import com.naver.maps.map.util.FusedLocationSource
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale


private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"
lateinit var binding : FragmentMapBinding
val stationList = listOf("공릉역","먹골역","석계역","하계역","화랑대역","태릉입구")

class MapFragment : Fragment(), OnMapReadyCallback {
    private lateinit var alarmManager: AlarmManager
    private var param1: String? = null
    private var param2: String? = null
    private lateinit var locationSource : FusedLocationSource
    private lateinit var naverMap: NaverMap
    private var marker: Marker? = null

    val g by lazy { android.location.Geocoder(requireContext(), Locale.KOREAN) } //geocoder
    var address: List<Address>? = null
    //장소검색 도로명 주소 받아오기
    private val getSearchResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            if (data != null) {
                val searchData = data.getStringExtra("data")
                binding.editSearchText .setText(searchData)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
        locationSource = FusedLocationSource(this,LOCATION_PERMISSION_REQUEST_CODE)
    }

    //지오코더 위경도를 주소로 바꾸기
    fun Geocoder(address: String, callback: (lat:Double?, lng:Double?) -> Unit) {
        val gecoder = Geocoder(requireContext())
        Thread {
            try{
                val adrresses = gecoder.getFromLocationName(address,1)
                if (adrresses!!.isNotEmpty()) {
                    val location = adrresses[0]
                    val lat = location.latitude
                    val lng = location.longitude
                    callback(lat,lng)
                }else {
                    callback(null,null)
                }
            }catch (e: IOException) {
                e.printStackTrace()
                callback(null,null)
            }
        }.start()
    }

    //역지오코더 위경도를 주소로 바꾸기
    fun Rgeocoder(lat:Double,lng: Double, callback:(result:String)-> Unit){
        Thread {
            var result =""
            try{
                address = g.getFromLocation(lat,lng,10)
                if (address!!.size > 0) {
                    address?.get(0)?.let { Log.d("bb", it.getAddressLine(0))
                        result = it.getAddressLine(0)
                    }
                }
                callback(result)
            }
            catch (e : IOException){
                e.printStackTrace()
            }
        }.start()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMapBinding.inflate(inflater,container,false)
        binding.navermap.getMapAsync(this)
        //터치 막기
        binding.editSearchText.isFocusable = false
        binding.editSearchText.setOnClickListener{
            val intent = Intent(requireContext(),SearchActivity::class.java)
            getSearchResult.launch(intent)
        }
        // search text에 있는 주소를 버튼을 누르면 위도 경도값을 따와서 이제 이 위도경도를 가지고 지도위에 표시
        binding.imageButton.setOnClickListener{//버튼을 누르면
            val address = binding.editSearchText.text.toString()//주소를 따옴
            Geocoder(address) { latitude, longitude -> // 지오코더를 통해 주소를 위도 경도로 바꿈
                if (latitude != null && longitude != null) {
                    Log.d("Geocoder", "위도: $latitude, 경도: $longitude")
                    requireActivity().runOnUiThread{ //ui 업데이트를 위해 메인스레드에서 실행
                        marker?.map = null // 기존에 마커를 삭제
                        marker = Marker() // 새로 마커 작성
                        marker?.position = LatLng(latitude, longitude)
                        marker?.icon = OverlayImage.fromResource(com.naver.maps.map.R.drawable.navermap_default_marker_icon_blue)
                        marker?.width = Marker.SIZE_AUTO
                        marker?.height = Marker.SIZE_AUTO
                        marker?.isIconPerspectiveEnabled = true
                        marker?.map = naverMap
                        //카메라 이동
                        val cameraUpdate = CameraUpdate.scrollTo(LatLng(latitude,longitude))
                        naverMap.moveCamera(cameraUpdate)
                    }

                } else {
                    Log.d("Geocoder", "주소를 찾을 수 없습니다.")
                }
            }
        }
        var stationId = 716
        var stationName = "공릉역"
        //spinner adapter
        val spinnerAdapter = ArrayAdapter<String>(requireContext(),android.R.layout.simple_list_item_1, stationList)
        binding.stationSpinner.adapter = spinnerAdapter
        //spinner에 선택된 아이템 정보 가져오기
        binding.stationSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Log.d("spinner", stationList.get(p2))
                stationName = stationList.get(p2)
                stationId = when(stationName) {
                    "공릉역" -> 716
                    "하계역" -> 715
                    "화랑대역" -> 646
                    "태릉입구" -> 645
                    "석계역" -> 644
                    "먹골역" -> 718
                    else -> {
                        Log.d("stationId", "아직 업데이트되지 않은 역정보입니다.")
                        716
                    }
                }
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }
        }
        var alarmMinute = ""
        var hour = ""
        //radio button
        var direction = ""
        binding.upDownRadio.setOnCheckedChangeListener{radioGroup, id ->
            getPublicTransportationData(stationId.toString()) {uptimes, downtimes ->
                val currentTime = Calendar.getInstance()
                hour = currentTime.get(Calendar.HOUR_OF_DAY).toString()//핸드폰 현재 시
                when(id) {
                    binding.upRadioBtn.id -> if(uptimes.isEmpty()){
                        Log.d("radio","없음")
                    }else{
                        val firstItem = uptimes.take(1).firstOrNull()
                        alarmMinute = firstItem?.substringBefore('(') ?: ""
                        Log.d("radio", alarmMinute )
                        direction = "상향행"
                    }
                    binding.downRadioBtn.id -> if(downtimes.isEmpty()){
                        Log.d("radio","없음")
                    }else{
                        val firstItem = downtimes.take(1).firstOrNull()
                        alarmMinute = firstItem?.substringBefore('(') ?: ""
                        Log.d("radio", alarmMinute )
                        direction = "하향행"
                    }
                }
            }
        }
        // 알람매니저
        alarmManager = requireContext().getSystemService(ALARM_SERVICE) as AlarmManager
        binding.alarmBtn.setOnClickListener{
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR).toString()
            val month = (calendar.get(Calendar.MONTH)+1).toString()
            val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH).toString()
            val time = year+ "-"+ month+"-"+dayOfMonth+" "+ hour + ":" + alarmMinute
            setAlarm(time)
            Log.d("alarm","알람이 ${time}에 설정됨")
            Toast.makeText(requireContext(),"${time}에 알람이 설정되었습니다.",Toast.LENGTH_SHORT).show()
        }
        return binding.root
    }
    private fun setAlarm(selectedDateTime: String) {
        // AlarmReceiver에 값 전달
        val receiverIntent = Intent(requireContext(), AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            requireContext(),
            0,
            receiverIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        // 기존 알람 취소
        alarmManager.cancel(pendingIntent)

        // 날짜 포맷을 바꿔주는 소스코드
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA)
        var datetime: Date? = null
        try {
            datetime = dateFormat.parse(selectedDateTime)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        Log.d("calendar","$datetime")
        val calendar = Calendar.getInstance()
        calendar.setTime(datetime)

        alarmManager.set(AlarmManager.RTC, calendar.getTimeInMillis(), pendingIntent)
        Log.d("aa","${calendar}")
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            MapFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }

        private const val LOCATION_PERMISSION_REQUEST_CODE = 1000
    }

    override fun onMapReady(naverMap: NaverMap) {
        this.naverMap = naverMap
        naverMap.mapType = NaverMap.MapType.Basic //네이버 지도 유형
        naverMap.setLayerGroupEnabled(NaverMap.LAYER_GROUP_TRAFFIC, true) // 네이버 실시간 교통정보 그룹
        naverMap.setLayerGroupEnabled(NaverMap.LAYER_GROUP_TRANSIT, true)// 네이버 대중교통 그룹
        naverMap.uiSettings.isLocationButtonEnabled = true //현재위치 버튼
        naverMap.locationSource = locationSource
        // 정류장 지하철역 마커 (추후 버스정류장도 할예정)
        val markerList = arrayListOf(
            LatLng(37.61717163458433, 127.07472872343648),//태릉입구역
            LatLng(37.620141667972206, 127.08382311192688),//화랑대역
            LatLng(37.61080277041527, 127.07770102477173),//먹골역 0
            LatLng(37.636752,127.067614),//하계역 0
            LatLng(37.625976,127.072819),//공릉역 0
            LatLng(37.615090979843025, 127.06705709598249),//석계역
        )

        for (m in markerList) {
            val marker = Marker()
            marker.position = m
            marker.icon = OverlayImage.fromResource(com.naver.maps.map.R.drawable.navermap_default_marker_icon_yellow)
            marker.width = Marker.SIZE_AUTO
            marker.height = Marker.SIZE_AUTO
            marker.isIconPerspectiveEnabled = true
            marker.map = naverMap
            // 정보창 설정
            val infoWindow = InfoWindow()
            var stationName = ""
            var stationId = 716 //공릉역 sationID
            //위경도로 지하철역 이름 가져오기
            Rgeocoder(m.latitude,m.longitude) {result ->
                Log.d("Rgecoder", result)
                val address = result.split(" ")
                Log.d("Rgecoder", address.toString())
                stationName = "${address.get(address.size - 1)}"
                Log.d("Rgecoder", stationName)
                // 각 지하철 역명에 해당하는 stationId 할당
                stationId = when(stationName) {
                    "공릉역" -> 716
                    "하계역" ->  715
                    "화랑대" -> 646
                    "태릉입구역" -> 645
                    "석계역" -> 644
                    "먹골역" ->718
                    else -> {
                        Log.d("stationId", "아직 업데이트되지 않은 역정보입니다.")
                        stationId
                    }
                }
                Log.d("stationId","${stationId}")
                // 정보창에 지하철 현재시간에 맞게 지하철 시간표 가장 빠른 2개 추출
                getPublicTransportationData(stationId.toString()) {uptimes, downtimes ->
                    infoWindow.adapter = object : InfoWindow.DefaultTextAdapter(requireContext()) {
                        override fun getText(infoWindow: InfoWindow): CharSequence {
                            val currentTime = Calendar.getInstance()
                            val hour = currentTime.get(Calendar.HOUR_OF_DAY)//핸드폰 현재 시
                            var uptimeText = ""
                            var downtimeText = ""
                            if(uptimes.isEmpty()){
                                uptimeText = "${hour}시에는 지하철이 없습니다.${hour+1}시에 다시 검색해주세요"
                            }else{
                                uptimeText = uptimes.take(2).joinToString(", ")
                            }
                            if(downtimes.isEmpty()){
                                downtimeText = "${hour}시에는 지하철이 없습니다. ${hour+1}시에 다시 검색해주세요"
                            }else{
                                downtimeText = downtimes.take(2).joinToString(", ")
                            }
                            return "$stationName\n상향: $uptimeText\n하향: $downtimeText"
                        }
                    }
                }
            }
            // 마커를 터치하면 정보창이 나타나게함
            val listner = Overlay.OnClickListener { overlay ->
                val marker = overlay as Marker
                if (marker.infoWindow == null) {
                    // 현재 마커에 정보 창이 열려있지 않을 경우 엶
                    infoWindow.open(marker)
                } else {
                    // 이미 현재 마커에 정보 창이 열려있을 경우 닫음
                    infoWindow.close()
                }
                true
            }

            marker.onClickListener = listner
            //정보창을 클릭하면 채팅방으로 넘어감
            infoWindow.setOnClickListener {
                val fManager = requireActivity().supportFragmentManager
                fManager.commit {
                    replace(R.id.frameLayout, ChatFragment())
                    addToBackStack(null)
                }
                return@setOnClickListener true
            }
        }
    }
    //대중교통 시간표 불러오기 함수
    private fun getPublicTransportationData(stationId: String, callback:(List<String>, List<String>)-> Unit){
        val retrofitAPI = retrofitConnection.getInstance().create(stationService::class.java)
        val call = retrofitAPI.getStationTimeTableData(
            "HFzt2MlKKNAzow6eacQK7TsnOIrG0jNcK5vZ3FV9mEQ",
            stationId
        )
        call.enqueue(object : Callback<stationTimeTableDTO> {
            override fun onResponse(
                call: Call<stationTimeTableDTO>,
                response: Response<stationTimeTableDTO>
            ) {
                val upTimes: MutableList<String> = mutableListOf()
                val downTimes: MutableList<String> = mutableListOf()
                val data = response.body()
                val currentTime = Calendar.getInstance()
                val hour = currentTime.get(Calendar.HOUR_OF_DAY)//핸드폰 현재 시
                val minute = currentTime.get(Calendar.MINUTE)// 현드폰 현재 분
                Log.d("currentTime","$hour $minute")

                data?.result?.OrdList?.up?.time?.forEach { time ->
                    if (time.Idx == hour) {
                        val timeTable = time.list // 해당 시간에 맞는 지하철 시간표
                        val regex = Regex("\\d+\\([^)]+\\)")
                        upTimes.addAll(
                            regex.findAll(timeTable)
                                .mapNotNull { matchResult ->
                                    val timeString = matchResult.value // ex) "04(동두천)"
                                    val time = timeString.substringBefore('(').toInt() // 분 부분 추출
                                    if (minute < time) {
                                        timeString
                                    } else {
                                        null
                                    }
                                }
                        )
                    }
                }
                data?.result?.OrdList?.down?.time?.forEach { time ->
                    if (time.Idx == hour) {
                        val timeTable = time.list // 해당 시간에 맞는 지하철 시간표
                        val regex = Regex("\\d+\\([^)]+\\)")
                        downTimes.addAll(
                            regex.findAll(timeTable)
                                .mapNotNull { matchResult ->
                                    val timeString = matchResult.value // ex) "04(동두천)"
                                    val time = timeString.substringBefore('(').toInt() // 분 부분 추출
                                    if (minute < time) {
                                        timeString
                                    } else {
                                        null
                                    }
                                }
                        )
                    }
                }
                callback(upTimes,downTimes)
            }
            override fun onFailure(call: Call<stationTimeTableDTO>, t: Throwable) {
                Toast.makeText(requireContext(),"업데이트 실패", Toast.LENGTH_SHORT).show()
                callback(emptyList(), emptyList())
            }
        })
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (locationSource.onRequestPermissionsResult(requestCode,permissions,grantResults)) {
            if (!locationSource.isActivated) { //권한이 거부됨
                naverMap.locationTrackingMode = LocationTrackingMode.None
            }
            return
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}
