package com.example.myapp

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {

    private lateinit var notificationManager: NotificationManager
    private lateinit var builder: NotificationCompat.Builder

    // Oreo and above requires channel to be set for Notification to work
    private val CHANNEL_ID = "channel1"
    private val CHANNEL_NAME = "Channel1"

    override fun onReceive(context: Context, intent: Intent) {

        notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT)
            )
            NotificationCompat.Builder(context, CHANNEL_ID)
        } else {
            NotificationCompat.Builder(context)
        }

        // Launch activity screen when notification is clicked
//        val intent2 = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
        // Set notification title
        builder.setContentTitle("지하철이 도착했습니다")
        // Set notification icon
        builder.setSmallIcon(R.mipmap.ic_launcher_round)
        // Automatically cancel notification on touch
        builder.setAutoCancel(true)

        builder.setContentIntent(pendingIntent)

        val notification: Notification = builder.build()
        notificationManager.notify(1, notification)
    }
}
