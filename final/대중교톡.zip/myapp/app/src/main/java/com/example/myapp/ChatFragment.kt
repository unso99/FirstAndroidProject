package com.example.myapp

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp.databinding.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.getValue
import com.google.firebase.storage.FirebaseStorage
import java.io.ByteArrayOutputStream
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class ChatFragment : Fragment() {
    lateinit var binding: FragmentChatBinding
    lateinit var myUid: String
    val messages = arrayListOf<ChatData>()
    var messageKeys: java.util.ArrayList<String> = arrayListOf()   //메시지 키 목록
    val adapter = MessageAdapter(messages)
    var REQUEST_CAMERA = 0

    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentChatBinding.inflate(inflater,container,false)
        Log.d("chat","채팅 프래그먼트 생성") // 이건 지워도 괜찮지 않을까

        // 메시지 RecyclerView adapter
        binding.recyclerMessage.adapter = adapter
        binding.recyclerMessage.layoutManager = LinearLayoutManager(requireContext())

        // 채팅창이 공백일 경우 전송(SEND) 버튼 비활성화
        binding.editMessage.addTextChangedListener { text ->
            binding.btnSend.isEnabled = text.toString() != ""
        }
        // 메시지 전송(SEND) 버튼 눌렀을 때
        binding.btnSend.setOnClickListener() {
            putMessage()

        }
        // 카메라 버튼 눌렀을 때
        binding.btnCamera.setOnClickListener(){
            TakePicture()
        }
        getMessage()
        return binding.root
    }

    // 텍스트 메시지 보내는 함수
    fun putMessage() {
        val msg = binding.editMessage.getText().toString()  //입력창에 작성한 내용 문자열로 받아서 msg 변수에 저장
        myUid = FirebaseAuth.getInstance().currentUser?.uid.toString()  //현재 사용자(=나)의 uid firebaseAuth에서 받아오기 (익명 Uid)
        val chat = ChatData(myUid, msg, getDateTimeString(),null)   //ChatData data class에 필요한 내용 넣고 chat 변수에 저장, 일반 메시지이므로 imageUrl은 null
        //Log 띄워서 확인하기
        Log.d("putMessage", chat.msg!!)             //메시지 내용
        Log.d("putMessage", getDateTimeString())    //메시지 보낸 시간
        FirebaseDatabase.getInstance().getReference("ChatRoom").child("chatRooms").child("messages")
            .push().setValue(chat).addOnSuccessListener {       //입력한 chat firebase database에 push
                Log.i("putMessage", "메시지 전송에 성공하였습니다.")
                binding.editMessage.text.clear()        //채팅 입력 후 입력창 비우기
            }.addOnCanceledListener {
                Log.i("putMessage", "메시지 전송에 실패하였습니다")
            }
    }
    // 입력한 메시지 firebase에서 가져오는 함수
    fun getMessage() {
        FirebaseDatabase.getInstance().getReference("ChatRoom").child("chatRooms").child("messages")
            .addValueEventListener(object : ValueEventListener {    //참조한 경로에서 event가 발생했을 때 ValueEventListener 호출
                override fun onCancelled(error: DatabaseError) {}
                override fun onDataChange(dataSnapshot: DataSnapshot) {     //데이터가 변경되었을 때 호출되는 메서드
                    messages.clear()
                    for (data in dataSnapshot.children) {
                        messages.add(data.getValue<ChatData>()!!)      //dataSnapshot의에서 ChatData 객체를 가져와 messages 목록에 추가
                        messageKeys.add(data.key!!)                    //채팅 키를 messageKeys 목록에 추가
                    }
                    adapter.notifyDataSetChanged()          //화면 업데이트
                    binding.recyclerMessage.scrollToPosition(messages.size - 1)    //스크롤 최하단으로 내리기
                }
            })
    }
    //메시지 보낸 시각 불러오는 함수
    fun getDateTimeString(): String {
        var localDateTime = LocalDateTime.now()
        localDateTime.atZone(TimeZone.getDefault().toZoneId())
        var dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
        return localDateTime.format(dateTimeFormatter).toString()
    }
    // 카메라 앱으로 이동하는 Intent 생성 및 실행 함수
    fun TakePicture() {
        var intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)    //이미지 캡처 액션 가진 intent 생성
        startActivityForResult(intent, REQUEST_CAMERA)          //생성한 intent로 카메라 앱 실행
    }

    // 사진 촬영 결과 처리
    //REQUEST_CAMERA 요청 코드와 Activity.RESULT_OK 결과 코드 확인하여 촬영이 성공한 경우에 처리
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAMERA && resultCode == Activity.RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap   //촬영한 이미지를 Bitmap형태로 가져옴
            uploadImageToFirebase(imageBitmap)                      //Firebase에 업로드 하기위한 함수 호출
        }
    }
    // Firebase에 이미지 업로드
    fun uploadImageToFirebase(imageBitmap: Bitmap) {
        val storageRef = FirebaseStorage.getInstance().reference    //Firebase Storage 경로 참조
        val imagesRef = storageRef.child("images/${UUID.randomUUID()}.jpg")     //업로드 할 이미지에 대한 참조 생성 및 경로 지정
        val baos = ByteArrayOutputStream()  //이미지 데이터 압축
        imageBitmap.compress(Bitmap.CompressFormat.JPEG, 90, baos)  //JPEG 형식으로 이미지 압축
        val imageData = baos.toByteArray()  //baos에서 바이트 배열 형태의 이미지 데이터 가져오기
        val uploadTask = imagesRef.putBytes(imageData)  //이미지 데이터 Firebase Storage에 업로드 작업하기
        uploadTask.addOnCompleteListener { task ->
            if (task.isSuccessful) {    //이미지 업로드가 성공했을 때
                imagesRef.downloadUrl.addOnSuccessListener { downloadUri ->     //업로드 된 이미지의 URL을 얻어오기
                    //이미지 URL을 문자열로 변환하여 imageUrl 변수에 저장
                    val imageUrl = downloadUri.toString()
                    //채팅방에 이미지 메시지 전송 함수 호출
                    sendImage(imageUrl)
                }.addOnFailureListener { exception ->
                    //URL을 얻어오지 못했을 때
                    Log.e("uploadImageToFirebase", "Failed to get download URL: ${exception.message}")
                }
            } else {
                //이미지 업로드 실패 시
                Log.e("uploadImageToFirebase", "Image upload failed: ${task.exception?.message}")
            }
        }
    }
    //이미지 메시지 보내는 함수
    fun sendImage(imageUrl: String) {
        myUid = FirebaseAuth.getInstance().currentUser?.uid.toString()      //현재 사용자(=나)의 uid firebaseAuth에서 받아오기 (익명 Uid)
        val image = ChatData(myUid, null, getDateTimeString(), imageUrl)//ChatData data class에 필요한 내용 넣고 image 변수에 저장, 이미지 메시지이므로 msg는 null
        FirebaseDatabase.getInstance().getReference("ChatRoom").child("chatRooms").child("messages")
            .push().setValue(image)             //촬영한 이미지 메시지를 참조한 경로 firebase database에 push
            .addOnSuccessListener {
                Log.i("sendMessageWithImage", "이미지 메시지 전송에 성공하였습니다.")
            }
            .addOnCanceledListener {
                Log.i("sendMessageWithImage", "이미지 메시지 전송에 실패하였습니다.")
            }
    }
    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            ChatFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}