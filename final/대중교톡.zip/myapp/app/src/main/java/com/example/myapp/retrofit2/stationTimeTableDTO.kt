package com.example.retrofit_example.retrofit2

data class stationTimeTableDTO(
    val result: Result
)