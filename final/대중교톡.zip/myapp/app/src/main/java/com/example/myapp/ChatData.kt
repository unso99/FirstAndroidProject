package com.example.myapp

// 각 채팅을 저장하는 객체
data class ChatData(
    val send_uid: String = "",      //채팅 보낸 사람의 uid
    val msg: String? = null,        //채팅 내용
    val send_time: String = "",     //채팅 보낸 시간
    val imageUrl: String? = null    //채팅이 사진일 경우 사진 Url
)